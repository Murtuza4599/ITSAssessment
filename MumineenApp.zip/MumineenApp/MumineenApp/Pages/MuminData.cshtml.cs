using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Text.RegularExpressions;

namespace MumineenApp.Pages
{
    public class MuminDataModel : PageModel
    {
		public MumineenInfo muminInfo = new MumineenInfo();
		public String errorMessage = "";
		public void OnGet()
		{
		}
		public void OnPost()
		{
			muminInfo.itsID = Request.Form["itsID"];
			muminInfo.name = Request.Form["name"];
			muminInfo.age = Request.Form["age"];
			muminInfo.gender = Request.Form["gender"];
			muminInfo.mobileNo = Request.Form["mobileNo"];
			muminInfo.email = Request.Form["email"];
			muminInfo.maritialStatus = Request.Form["maritialStatus"];
			muminInfo.address = Request.Form["address"];

			if (muminInfo.itsID.Length == 0 || muminInfo.name.Length == 0 ||
				muminInfo.age.Length == 0 || muminInfo.mobileNo.Length == 0 || 
				muminInfo.email.Length == 0 || muminInfo.address.Length == 0)
			{
				errorMessage = "All the fields are required";
				return;
			}
			else if(muminInfo.itsID.Length > 8 || muminInfo.itsID.Length < 8)
			{
				errorMessage = "ITS ID should be exactly 8 digits";
				return;
			}
			else if (!AgeValidate(muminInfo.age))
			{
				errorMessage = "Enter Valid Age";
				return;
			}
			else if (!IsPhoneNumber(muminInfo.mobileNo))
			{
				errorMessage = "Enter Valid Mobile Number";
				return;
			}
			else if (!IsValid(muminInfo.email))
			{
				errorMessage = "Enter Valid Email Address";
				return;
			}

			try
			{
				String connectionString = "Data Source=.\\sqlexpress;Initial Catalog=Mumineen_info;Integrated Security=True";
				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					String sql = "INSERT INTO mumin_data " +
						"(itsID, name, age, gender, mobileNo, email, maritialStatus, address)" +
						" VALUES" +
						" (@itsID, @name, @age, @gender, @mobileNo, @email, @maritialStatus, @address)";

					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						command.Parameters.AddWithValue("@itsID", muminInfo.itsID);
						command.Parameters.AddWithValue("@name", muminInfo.name);
						command.Parameters.AddWithValue("@age", muminInfo.age);
						command.Parameters.AddWithValue("@gender", muminInfo.gender);
						command.Parameters.AddWithValue("@mobileNo", muminInfo.mobileNo);
						command.Parameters.AddWithValue("@email", muminInfo.email);
						command.Parameters.AddWithValue("@maritialStatus", muminInfo.maritialStatus);
						command.Parameters.AddWithValue("@address", muminInfo.address);

						command.ExecuteNonQuery();
					}
				}
			}
			catch (Exception ex)
			{
				errorMessage = ex.Message;
				return;
			}

			muminInfo.itsID = "";
			muminInfo.name = "";
			muminInfo.age = "";
			muminInfo.gender = "";
			muminInfo.mobileNo = "";
			muminInfo.email = "";
			muminInfo.maritialStatus = "";
			muminInfo.address = "";

			Response.Redirect("/Index");
		}

		private static bool AgeValidate(string age)
		{
			int yrs;
			return (int.TryParse(age, out yrs) && yrs >= 0 && yrs <= 100);
		}
		private static bool IsPhoneNumber(string number)
		{
			return (number[0] == '+' && number[1] == '9' && number[2] == '1' 
					&& number.Length == 13 && IsDigit(number.Substring(3)));
		}
		private static bool IsDigit(string number)
		{
			foreach (char c in number)
			{
				if (c < '0' || c > '9')
				{
					return false;
				}
			}
			return true;
		}
		private static bool IsValid(string email)
		{
			string regex = @"^[^@\s]+@[^@\s]+\.(com|net|org|gov)$";

			return Regex.IsMatch(email, regex, RegexOptions.IgnoreCase);
		}
	}
}
