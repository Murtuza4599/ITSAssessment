﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace MumineenApp.Pages
{
	public class IndexModel : PageModel
	{
		public List<MumineenInfo> listMumin = new List<MumineenInfo>();
		public void OnGet()
		{
			try
			{
				String connectionString = "Data Source=.\\sqlexpress;Initial Catalog=Mumineen_info;Integrated Security=True";

				using (SqlConnection connection = new SqlConnection(connectionString))
				{
					connection.Open();
					String sql = "SELECT * FROM mumin_data";
					using (SqlCommand command = new SqlCommand(sql, connection))
					{
						using (SqlDataReader reader = command.ExecuteReader())
						{
							while (reader.Read())
							{
								MumineenInfo muminInfo = new MumineenInfo();
								muminInfo.itsID = "" + reader.GetInt32(0);
								muminInfo.name = reader.GetString(1);
								muminInfo.age = "" + reader.GetInt32(2);
								muminInfo.gender = reader.GetString(3);
								muminInfo.mobileNo = reader.GetString(4);
								muminInfo.email = reader.GetString(5);
								muminInfo.maritialStatus = reader.GetString(6);
								muminInfo.address = reader.GetString(7);

								listMumin.Add(muminInfo);
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Exception: " + ex.ToString());
			}
		}
	}

	public class MumineenInfo
	{
		public String itsID;
		public String name;
		public String age;
		public String gender;
		public String mobileNo;
		public String email;
		public String maritialStatus;
		public String address;
	}
}