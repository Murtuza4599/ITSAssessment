Steps for how to proceed with the project:-

1) Open "MumineenApp.sin" file in Visual Studio

2) Connect to the Database with name - "Mumineen_info"
	and check if the connection string is proper or not
	You can find it in database properties
	Following is my connection string:
	"Data Source=.\sqlexpress;Initial Catalog=Mumineen_info;Integrated Security=True"

3) Create the table with the following query:

CREATE TABLE mumin_data (
    itsID          INT           NOT NULL	 PRIMARY KEY,
    name           VARCHAR (75)  NOT NULL,
    age            INT           NOT NULL,
    gender         VARCHAR (10)  NOT NULL  CHECK (gender in ('Male','Female','Other')),
    mobileNo       VARCHAR (15)  NULL,
    email          VARCHAR (100) NOT NULL  UNIQUE,
    maritialStatus VARCHAR (10)  NOT NULL  CHECK (maritialStatus in ('Single','Engaged','Married','Divorced','Widowed')),
    address        VARCHAR (150) NULL,
);

4) I have also provided with images of my database and also images of web look

5) Now you can run the application in Visual Studio

